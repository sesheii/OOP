package good.oop.lab.cars;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Qualifier("toyota")
public class Toyota implements Car {

    @Value("${Toyota.model}")
    private String model;

    @Value("${Toyota.price}")
    private String price;

    @Value("${Toyota.speed}")
    private String speed;

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getPrice() {
        return price;
    }

    @Override
    public String getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return getModel() + " (" + getPrice() + ", " + getSpeed() + ")";
    }
}
