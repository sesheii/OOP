package good.oop.lab.cars;
public interface Car {

//    public void startEngine();
    public String getModel();
    public String getPrice();
    public String getSpeed();

}
