package good.oop.lab.cars;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Qualifier("ford")
public class Ford implements Car {
    @Value("${Ford.model}")
    private String model;

    @Value("${Ford.price}")
    private String price;

    @Value("${Ford.speed}")
    private String speed;

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getPrice() {
        return price;
    }

    @Override
    public String getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return getModel() + " (" + getPrice() + ", " + getSpeed() + ")";
    }
}