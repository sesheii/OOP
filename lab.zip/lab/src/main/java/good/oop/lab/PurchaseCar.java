package good.oop.lab;

import good.oop.lab.cars.CarShop;
import good.oop.lab.config.AppConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class PurchaseCar {

    public static void main(String[] args) {
//        SpringApplication.run(LabApplication.class, args);

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        CarShop carShop = context.getBean("carShop", CarShop.class);


        System.out.println("\n\n\n\n\n\n\n");
        System.out.println("You are in a car shop. How many cars would you like to buy?");
        System.out.println(carShop.getAvailableCars());
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        Person person = new Person();

        System.out.println("Great. Which car would you like to buy? (choose by typing in 0, 1, 2 and -1 to exit)");
        for (int i = 0; i < n; ++i) {

            int m = scanner.nextInt();

            switch (m) {

                case -1:
                    i = n;
                    break;
                default:
                    System.out.println("You've successfully purchased " + carShop.showCar(m));
                    person.purchasedCars.add(carShop.buy(m));
                    break;
            }
        }

        System.out.println("Thanks for the purchase, all the cars you bought are: ");
        System.out.println(person.purchasedCars);
        System.out.println("Calculate the total yourself and pay and have a nice day");

        scanner.close();
        context.close();
    }
}