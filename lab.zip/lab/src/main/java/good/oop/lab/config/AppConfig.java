package good.oop.lab.config;

import good.oop.lab.cars.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import java.util.Arrays;
import java.util.List;

@Configuration
@PropertySource("classpath:Car.properties")
@ComponentScan("good.oop.lab.cars")
public class AppConfig {

//    @Bean
//    public Toyota toyota() {
//        return new Toyota();
//    }
//
//    @Bean
//    public Skoda skoda() {
//        return new Skoda();
//    }
//
//    @Bean
//    public Ford ford() {
//        return new Ford();
//    }

    @Bean
    @Autowired
    public List<Car> availableCars(Car toyota, Car skoda, Car ford) {
        return Arrays.asList(toyota, skoda, ford);
    }
}
