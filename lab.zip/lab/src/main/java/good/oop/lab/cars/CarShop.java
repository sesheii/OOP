package good.oop.lab.cars;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Qualifier("carShop")
public class CarShop {

    private List<Car> availableCars;

    @Autowired
    public CarShop(List<Car> availableCars){
        this.availableCars = availableCars;
    }

    public Car buy(Integer index) {
//        System.out.println("You've successfully purchased " + availableCars.get(index));
        return availableCars.get(index);
    }

    public List<Car> getAvailableCars() {
        return availableCars;
    }

    public Car showCar(int index) {
        return availableCars.get(index);
    }
}
