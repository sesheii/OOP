package good.oop.lab.cars;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Qualifier("skoda")
public class Skoda implements Car {
    @Value("${Skoda.model}")
    private String model;

    @Value("${Skoda.price}")
    private String price;

    @Value("${Skoda.speed}")
    private String speed;

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getPrice() {
        return price;
    }

    @Override
    public String getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return getModel() + " (" + getPrice() + ", " + getSpeed() + ")";
    }
}
