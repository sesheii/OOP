package good.oop.lab;
import good.oop.lab.cars.Car;

import java.util.ArrayList;
import java.util.List;

public class Person {
    public List<Car> purchasedCars = new ArrayList<>();

}
